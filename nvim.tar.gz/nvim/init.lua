require "user/options"
require "user/keymaps"
require "user/plugins"

require "colorscheme/gruvbox"

require "treesitter-cfg"
require "neotree-cfg"
require "lualine-cfg"
require "bufferline-cfg"
require "autopairs-cfg"
require "telescope-cfg"

require "lsp-cfg"
