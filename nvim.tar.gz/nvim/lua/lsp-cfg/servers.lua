local signs = { Error = " ", Warn = " ", Hint = " ", Info = " " }


for type, icon in pairs(signs) do
  local hl = "DiagnosticSign" .. type
  vim.fn.sign_define(hl, { text = icon, texthl = hl, numhl = hl })
end


local lspconfig = require "lspconfig"
local capabilities = require("cmp_nvim_lsp").default_capabilities()

lspconfig["rust_analyzer"].setup { capabilities = capabilities }
lspconfig["pyright"].setup { capabilities = capabilities }


lspconfig["clangd"].setup {
    cmd = {
        "clangd",
        "--background-index",
        "--suggest-missing-includes",
    },
    filetypes = { "c", "cpp", "objc", "objcpp" },
}
