local opts = { noremap = true, silent = false }

---------------------------------------------
-----------------Custom----------------------
---------------------------------------------

vim.keymap.set('n', "<leader>w", ":w<cr>", opts)
vim.keymap.set('n', "<leader>q", ":q<cr>", opts)
vim.keymap.set('n', "<leader>z", ":q!<cr>", opts)

vim.keymap.set('n', "<leader>c", ":nohl<cr>", opts)
vim.keymap.set({'n', 'v'}, "<leader>e", "$", opts)
vim.keymap.set('n', "<leader>d", "\"_d", opts)
vim.keymap.set('n', "x", "\"_x", opts)

vim.keymap.set('n', "<leader>h", "<C-w>h", opts)
vim.keymap.set('n', "<leader>l", "<C-w>l", opts)
vim.keymap.set('n', "<leader>j", "<C-w>j", opts)
vim.keymap.set('n', "<leader>k", "<C-w>k", opts)

vim.keymap.set('v', "<", "<gv", opts)
vim.keymap.set('v', ">", ">gv", opts)

vim.keymap.set('i', "jk", "<esc>", opts)

---------------------------------------------
-----------------Plugins---------------------
---------------------------------------------

vim.keymap.set('n', "<tab>", ":NeoTreeFocusToggle<cr>", opts)

vim.keymap.set('n', "<C-k>", ":BufferLineCycleNext<cr>", opts)
vim.keymap.set('n', "<C-j>", ":BufferLineCyclePrev<cr>", opts)
vim.keymap.set('n', "<C-d>", ":bdelete<cr>", opts)

vim.keymap.set('n', "gd", ":lua vim.lsp.buf.declaration()<cr>")
