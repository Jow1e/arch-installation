packer = require "packer"


local function loader(use)
    -- packer itself
    use "wbthomason/packer.nvim"

    -- ui
    use "MunifTanjim/nui.nvim"

    -- utility
    use "nvim-lua/plenary.nvim"

    -- neotree
    use "nvim-neo-tree/neo-tree.nvim"
    use "nvim-tree/nvim-web-devicons"

    -- gruvbox
    use "ellisonleao/gruvbox.nvim"

    -- treesitter
    use { "nvim-treesitter/nvim-treesitter", run = ":TSUpdate" }

    -- status line
    use "nvim-lualine/lualine.nvim"

    -- buffer line
    use {"akinsho/bufferline.nvim", tag = "v3.*" }

    -- auto pairs
    use "windwp/nvim-autopairs"

    -- telescope
    use "nvim-telescope/telescope.nvim"
    -- fzf native (for performance)
    use {
        "nvim-telescope/telescope-fzf-native.nvim",
        run = "cmake -S. -Bbuild -DCMAKE_BUILD_TYPE=Release && cmake --build build --config Release && cmake --install build --prefix build"
    }

    -- autocompletion
    use 'neovim/nvim-lspconfig'
    use 'hrsh7th/cmp-nvim-lsp'
    use 'hrsh7th/cmp-buffer'
    use 'hrsh7th/cmp-path'
    use 'hrsh7th/cmp-cmdline'
    use 'hrsh7th/nvim-cmp'

    -- snippets
    use "L3MON4D3/LuaSnip"

end

return packer.startup(loader)
