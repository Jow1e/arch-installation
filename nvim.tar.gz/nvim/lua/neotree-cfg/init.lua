require("neo-tree").setup {
    close_if_last_window = true
}
