ts = require "nvim-treesitter.configs"

ts.setup {
    ensure_installed = { "lua", "help", "c", "cpp", "rust", "python", "bash" },
    sync_install = false,
    auto_install = false,

    highlight = {
        enable = true,
        additional_vim_regex_highlighting = false
    },

    autopairs = {
        enable = true
    }
}
